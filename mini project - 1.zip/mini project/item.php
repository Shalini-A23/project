<?php
include("db_config.php");
//As said table number is carried out throught the session we can also check integrity
if ( ! isset($_GET['table_no']) ) 
{
  die("Please Login correctly");
}
//table_no and token_no is stored in variable using GET
//It is not secure to use GET variable it should be changed later
$table_no=$_GET['table_no'];
$token_no=$_GET['token_no'];
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="icon" href="image/logo.png">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
  <title>MENU</title>
  <link rel="stylesheet" type="text/css" href="swiper.min.css">
  <link rel="stylesheet" type="text/css" href="swiper_style.css">
  <script type="text/javascript" href="swiper_script.js"></script>
  <style type="text/css">
    .button
    {
      margin-left: -80px;
    }
  </style>
</head>
<body>
<form method=post>
  <div class="button">
    <center>
    <!--The category is fetched from the category table so that it will be easy if admin wants to change or add-->
    <?php
    $sql="SELECT DISTINCT * from category where `status`='1'";
    $result=mysqli_query($con,$sql);
    while($row=mysqli_fetch_array($result))
    {
    ?>
      <a style="text-transform: uppercase;" class="btn" href="item.php?category_no=<?php echo $row['category_no'];?>&table_no=<?php echo $table_no;?>&token_no=<?php echo $token_no;?>"><?php echo $row['name']; ?></a>
    <?php
    }
    ?>
    </center>
  </div>
  <!-- Swiper -->
  <div class="swiper-container">
    <div class="swiper-wrapper">
      <!--The snacks menu is fetched from the snacks table so that it will be easy if admin wants to change or add-->
      <?php
      $sql="SELECT DISTINCT * from item where category_no='".$_GET['category_no']."' && quantity='1'";
      $category_no=$_GET['category_no'];
      $result=mysqli_query($con,$sql);
      while($row=mysqli_fetch_array($result))
      {
      ?> 
        <div class="swiper-slide">
          <div class="imgBx">
            <a href="item_insert.php?&token_no=<?php echo $token_no;?>&item_id=<?php echo $row['item_id'];?>&quantity=<?php echo $row['quantity'];?>&table_no=<?php echo $table_no;?>"><img name="my_image" src="image/<?php echo $row['image']; ?>"></a>
          </div>
          <div class="details">
          <h3 style="text-transform: uppercase;"><?php echo $row['item_name']; ?><br><span>Rs. <?php echo $row['cost']; ?>/-</span>
          </div>
        </div> 
      <?php
      }
      ?>
    </div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
  </div>
</form>
<script type="text/javascript" src="swiper.min.js"></script>
<script>
	var swiper = new Swiper('.swiper-container', {
	effect: 'coverflow',
	loop: false,
	centeredSlides: true,
	slidesPerView: 'auto',
	initialSlide: 1,
	keyboardControl: true,
	mousewheelControl: true,
	lazyLoading: true,
	preventClicks: true,
	preventClicksPropagation: true,
	lazyLoadingInPrevNext: true,
    grabCursor: true,
      coverflowEffect: 
      {
        rotate: 60,
        stretch: 0,
        depth: 500,
        modifier: 1,
        slideShadows : true,
      },
      pagination: 
      {
        el: '.swiper-pagination',
      },
});

</script>
</body>
</html>