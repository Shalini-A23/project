<?php
include_once('db_config.php');

if(isset($_POST['submit']))
{
	$uploads_dir='image';
	$tmp_name=$_FILES["image"]["tmp_name"];
	$name=basename($_FILES["image"]["name"]);
	if(move_uploaded_file($tmp_name, "$uploads_dir/$name"))
	{
		$sql="INSERT INTO `item` (`category_no`,`item_name`, `cost`, `image`,`quantity`) VALUES ('".$_POST['category_no']."','".$_POST['item_name']."','".$_POST['cost']."', '".$_FILES["image"]["name"]."','1')";
		$result=mysqli_query($con,$sql);
		if($result)
		{
			header('Location: admin_register.php?msg=done');
		}else
		{
			echo "SQL ERROR";
		}
	}
	else
	{
		echo "upload error";
	}
}
elseif(isset($_POST['add']))
{	
	$sql="INSERT INTO `login` (`table_no`,`code`,`status`,`mode`) VALUES ('".$_POST['room_no']."tb-0".$_POST['table_no']."','#".$_POST['code']."','empty','user')";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		header('Location: admin_add_table.php?msg=done');
	}
	else
	{
		echo "SQL ERROR";
	}
}
elseif(isset($_POST['add_admin']))
{	
	$sql="INSERT INTO `login` (`table_no`,`code`,`status`,`mode`) VALUES ('".$_POST['table_no']."','#".$_POST['code']."','empty','admin')";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		header('Location: admin_add_table.php?msg=done');
	}
	else
	{
		echo "SQL ERROR";
	}
}
elseif(isset($_POST['add_cat']))
{	
	$sql="INSERT INTO `category` (`name`,`status`) VALUES ('".$_POST['category']."','0')";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		header('Location: admin_add_category.php?msg=done');
	}
	else
	{
		echo "SQL ERROR";
	}
}
elseif(isset($_POST["update"]))
{
	$uploads_dir='image';
	$tmp_name=$_FILES["image"]["tmp_name"];
	$name=basename($_FILES["image"]["name"]);
	if(move_uploaded_file($tmp_name, "$uploads_dir/$name"))
	{
		$sql="UPDATE `item` SET `item_name` = '".$_POST['item_name']."' , `cost` = '".$_POST['cost']."',`image` = '".$_FILES["image"]["name"]."' WHERE `item_id` = '".$_POST['item_id']."' ";
		$result=mysqli_query($con,$sql);
		if($result)
		{
			header('Location: admin_view.php?msg=updated&category_no='.$_GET['category_no']);
		}else
		{
			echo "ERROR: UPDATED FAILED";
		}
	}
	else
	{
		echo "Wrng";
	}
}
elseif(isset($_POST["update_cat"]))
{	
	$sql="UPDATE `category` SET `name` = '".$_POST['category_name']."' WHERE `category_no` = '".$_POST['category_no']."' ";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		header('Location: admin_view_category.php?msg=updated');
	}
	else
	{
		echo "ERROR: UPDATED FAILED";
	}
}
elseif(isset($_POST["update_table"]))
{	
	$sql="UPDATE `login` SET `code` = '".$_POST['code']."' WHERE `table_no` = '".$_POST['table_no']."' ";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		header('Location: admin_view_table.php?msg=updated');
	}
	else
	{
		echo "ERROR: UPDATED FAILED";
	}
}
elseif($_GET['mode']=="delete")
{
	$sql = "DELETE FROM `item` WHERE `item_id` = '".$_GET['item_id']."'";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		header('Location: admin_view.php?msg=DELETED SUCCESSFULLY&category_no='.$_GET['category_no']);
	}else
	{
		echo "ERROR: DELETED FAILED";
	}
}
elseif($_GET['mode']=="do")
{
	$sql = "SELECT quantity FROM `item` where item_id='".$_GET['item_id']."' ";
	$result=mysqli_query($con,$sql);
	$row=mysqli_fetch_array($result);
	if($row['quantity']=='1')
	{
		$sql = "UPDATE `item` SET `quantity` = '0' where item_id='".$_GET['item_id']."' ";
		$result=mysqli_query($con,$sql);
		if($result)
		{
			header('Location: admin_view.php?msg=&category_no='.$_GET['category_no']);
		}else
		{
			echo "ERROR: PROCESS FAILED";
		}
	}
	else
	{
		$sql = "UPDATE `item` SET `quantity` = '1' where item_id='".$_GET['item_id']."' ";
		$result=mysqli_query($con,$sql);
		if($result)
		{
			header('Location: admin_view.php?msg=&category_no='.$_GET['category_no']);
		}else
		{
			echo "ERROR: PROCESS FAILED";
		}
	}
}
elseif($_GET['mode']=="do_cat")
{
	$sql = "SELECT status FROM `category` where category_no='".$_GET['category_no']."' ";
	$result=mysqli_query($con,$sql);
	$row=mysqli_fetch_array($result);
	if($row['status']=='1')
	{
		$sql = "UPDATE `category` SET `status` = '0' where category_no='".$_GET['category_no']."' ";
		$result=mysqli_query($con,$sql);
		if($result)
		{
			header('Location: admin_view_category.php?msg=');
		}else
		{
			echo "ERROR: PROCESS FAILED";
		}
	}
	else
	{
		$sql = "UPDATE `category` SET `status` = '1' where category_no='".$_GET['category_no']."' ";
		$result=mysqli_query($con,$sql);
		if($result)
		{
			header('Location: admin_view_category.php?msg=');
		}else
		{
			echo "ERROR: PROCESS FAILED";
		}
	}
}
elseif($_GET['mode']=="do_table")
{
	$sql = "SELECT status FROM `login` where table_no='".$_GET['table_no']."' ";
	$result=mysqli_query($con,$sql);;
	$row=mysqli_fetch_array($result);
	if($row['status']=='empty')
	{
		$sql = "UPDATE `login` SET `status` = '0' where table_no='".$_GET['table_no']."' ";
		$result=mysqli_query($con,$sql);
		if($result)
		{
			header('Location: admin_view_table.php?msg=');
		}else
		{
			echo "ERROR: PROCESS FAILED";
		}
	}
	else
	{
		$sql = "UPDATE `login` SET `status` = 'empty' where table_no='".$_GET['table_no']."' ";
		$result=mysqli_query($con,$sql);
		if($result)
		{
			header('Location: admin_view_table.php?msg=');
		}else
		{
			echo "ERROR: PROCESS FAILED";
		}
	}
}
elseif($_GET['mode']=="delete_cat")
{
	$sql = "SELECT name FROM `category` where category_no='".$_GET['category_no']."' ";
	$result=mysqli_query($con,$sql);

	$sql = "DELETE FROM `item` WHERE `category_no` = '".$_GET['category_no']."' ";
	$result=mysqli_query($con,$sql);

	$sql = "DELETE FROM `category` WHERE `category_no` = '".$_GET['category_no']."' ";
	$result=mysqli_query($con,$sql);

	if($result)
	{
		header('Location: admin_view_category.php?msg=DELETED SUCCESSFULLY');
	}else
	{
		echo "ERROR";
	}
}
elseif($_GET['mode']=="delete_table")
{
	$sql = "DELETE FROM `login` WHERE `table_no` = '".$_GET['table_no']."'";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		header('Location: admin_view_table.php?msg=DELETED SUCCESSFULLY');
	}else
	{
		echo "ERROR: DELETED FAILED";
	}
}
elseif($_GET['mode']=="get_it")
{
	$table_no=$_GET['table_no'];
	$token_no=$_GET['token_no'];
	$sql="UPDATE `bill` SET `status`='get it' where `table_no`='".$table_no."' and `token_no`='".$token_no."' and `date`='".date("y/m/d")."' ";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		header("Location:admin_order.php");
	}else
	{
		echo "ERROR: Order closed FAILED";
	}
}
elseif($_GET['mode']=="cancel")
{
	$table_no=$_GET['table_no'];
	$token_no=$_GET['token_no'];
	$sql="UPDATE `bill` SET `status`='canceled' where `table_no`='".$table_no."' and `token_no`='".$token_no."' and `date`='". date("y/m/d") ."' ";
	$result=mysqli_query($con,$sql);

	$sql="UPDATE `item` SET `quantity`=1";
	$result=mysqli_query($con,$sql);

	$sql="UPDATE `login` SET `status`='empty' where `table_no`='".$table_no."' ";
	$result=mysqli_query($con,$sql);

	$sql="UPDATE `customer_details` SET `payment_status`='canceled' where `table_no`='".$table_no."' and `token_no`='".$token_no."' and `date`='". date("y/m/d") ."' ";
	$result=mysqli_query($con,$sql);

	if($result)
	{
		header("Location:order_canceled.php");
	}else
	{
		echo $sql;
	}
}
elseif($_GET['mode']=="delivered")
{
	$table_no=$_GET['table_no'];
	$token_no=$_GET['token_no'];
	$sql="UPDATE `bill` SET `status`='delivered' where `table_no`='".$table_no."' and `token_no`='".$token_no."' and `date`='". date("y/m/d") ."' ";
	$result=mysqli_query($con,$sql);

	$sql="UPDATE `customer_details` SET `payment_status`='paid' where `table_no`='".$table_no."' and `token_no`='".$token_no."' and `date`='". date("y/m/d") ."' ";
	$result=mysqli_query($con,$sql);

	$sql="UPDATE `item` SET `quantity`=1";
	$result=mysqli_query($con,$sql);

	if($result)
	{
		header("Location:deliver_details.php");
	}else
	{
		echo $sql;
	}
}
elseif($_GET['mode']=="checked_out") 
{
	$table_no=$_GET['table_no'];
	$sql="UPDATE `login` SET `status`='empty' where table_no='".$table_no."' ";
	$result=mysqli_query($con,$sql);

	if($result)
	{
		header("Location: on_going.php");
	}else
	{
		echo $sql;
	}
}
elseif($_GET['mode']=="logout")
{
	header('Location: admin_login.php');
}
else
{
	echo "Total lose";
}
