<!DOCTYPE html>
<html>
<head>
  <title>FEEDBACK</title>
  <style type="text/css">
  table
  {
    font-family: "Kaushan Script", cursive !important;
    border-collapse: collapse;
    box-shadow: 0px 0px 10px grey;
    font-weight: bold;
    color: black;
    opacity: 0.9;
    background-color: white;
    width: 30%;
    margin-left: 0px;
  }
  td,th
  {
    border: 1px solid black;
    padding: 20px;
  }
  tr,td
  {
    padding: 10px;
  }
  tr:nth-child(even)
  {
    background-color: f2f2f2;
  }
  th
  {
    background-color: #4CAF50;
    color: white;
  }

.btnn
{
  font-family: "Kaushan Script", cursive !important;
  margin-left: 50px;
  margin-top: 29px;
  padding:10px 30px;
  color:black;
  text-decoration: none;
  transition: 0.6s ease;
  transform: translate(-50%,-50%);
  font-family: verdana;
  font-weight: bold;
  border:4px solid #66FFCC;
  background-color: silver;
  font-size: 15px;
}

.active, .btnn:hover
{
  color:black;
  border:4px solid #66FFCC;
  background-color: white;
  text-shadow: 0 0 20px white;
}
input,option,select,textarea
{
  font-color:#e5e5e5; 
  box-sizing: border-box;
  border-radius:5px;
  border:2px solid #e5e5e5;
  padding:10px;
  font-size:15px;
}
.btnn a
{
  font-color:#e5e5e5; 
  box-sizing: border-box;
  border-radius:5px;
  border:2px solid #e5e5e5;
  padding:10px;
  font-size:15px;
}
body
{
  background: url(image/backk.jpg);
  background-size: cover;
}
iframe
    {
      background-color: white;
      border: 3px solid black;
      opacity: 0.9;
    }
.dropbtn {
  font-family: "Kaushan Script", cursive !important;
  margin-left: 50px;
  border-radius:5px;
  margin-top: 29px;
  padding:10px 30px;
  color:black;
  text-decoration: none;
  transition: 0.6s ease;
  transform: translate(-50%,-50%);
  font-family: verdana;
  cursor: pointer;
  font-weight: bold;
  border:4px solid #66FFCC;
  background-color: silver;
  font-size: 15px;
}

.active, .dropbtn:hover{
  color:black;
  border:4px solid #66FFCC;
  background-color: white;
  text-shadow: 0 0 20px white;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  overflow: auto;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  padding:10px 30px;
  color:black;
  text-decoration: none;
  display: block;
}

.dropdown a:hover {background-color: #ddd;}

.show {display: block;}
a
{
  text-decoration: none;
}
img
{
  border-radius: 10px;
  border: 5px solid #e5e5e5;
}
img:hover
{
  border: 5px solid white;
}
.bt
{
  border-radius: 50px;
  border: 5px solid lightblue;
}
.bt:hover
{
  border: 5px solid white;
}
</style>
</head>
<body>
<center>
  <div class="dropdown">
    <button onclick="myFunction()" class="dropbtn">ADD</button>
      <div id="myDropdown" class="dropdown-content">
        <a href="admin_register.php?msg=">ADD FOOD ITEMS</a>
        <a href="admin_add_category.php?msg=">ADD CATEGORY</a>
        <a href="admin_add_table.php?msg=">ADD TABLES</a>
      </div>
    </div>
    <div class="dropdown">
    <button onclick="myFunction1()" class="dropbtn">VIEW</button>
      <div id="myDropdown1" class="dropdown-content">
        <a href="admin_view.php?msg=&category_no=1">VIEW FOOD ITEMS</a>
        <a href="admin_view_category.php?msg=">VIEW CATEGORY</a>
        <a href="admin_view_table.php?msg=">VIEW TABLES</a>
      </div>
    </div>
    <a href="frame.php"><input class="btnn" type="submit" value="TABLE"></a>
    <a href="feedback.php"><input class="btnn active" type="submit" value="FEEDBACK"></a>
    <a href="status.php"><input class="btnn" type="submit" value="STATUS"></a>
    <a href="add_admin.php?msg=" style="position: absolute; right: 6%;"><img class="bt" src="image/add_user.png" width="50px" height="50px;"></a>
    <a href="admin_action.php?mode=logout" style="position: absolute; right: 1%;"><img src="image/logout.jpg" width="40px" height="50px;"></a>
  </center>
<?php
if($_GET['msg']!='')
{
  echo "<script>confirm('*********".$_GET['msg']."*********')</script>";
}
?>
<br><br><br>
<center>
<?php
include_once("db_config.php");
$sql="SELECT DISTINCT * from feedback";
$result=mysqli_query($con,$sql);
$i=1;
?>
<table border="1">
<tr>
<th>S.No</th>
<th>TABLE NUMBER</th>
<th>CODE</th>
<th>ACTION</th>
</tr>

<tr>
<?php
while($row=mysqli_fetch_array($result))
{
?>
</tr>
<td><center><?php echo $i++ ?></center></td>
<td style="text-transform: uppercase;"><?php echo $row['name']; ?></td>
<td><?php echo $row['issues']; ?></td>
<td>
<center>
<!--<a href="admin_action.php?table_name=<?php echo $table_no ;?>&mode=delete&item_id=<?php echo $row['item_id']; ?>">Delete</a>-->
<?php
echo "<a onclick=\"return confirm('Are you sure to DELETE this table?')\" href=\"admin_action.php?mode=solved&feedback_no=".$row['feedback_no']."\"><font color=red>&times</font></a>";
?>

</center>
</td>
</tr>

<tr>
<?php
}
?>
</tr>
</table>
</center>
</body>
</html>
<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

function myFunction1() {
  document.getElementById("myDropdown1").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>