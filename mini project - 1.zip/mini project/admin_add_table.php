<!DOCTYPE html>
<html>
<head>
  <link rel="icon" href="image/logo.png">
	<title>ADD TABLE</title>
	<link rel="stylesheet" href="styles.css">
</head>
<style type="text/css">
  .btt
{
  border-radius: 10px;
  border: 5px solid #e5e5e5;
}
.btt:hover
{
  border: 5px solid white;
}
.bt
{
  border-radius: 50px;
  border: 5px solid lightblue;
}
.bt:hover
{
  border: 5px solid white;
}
    .btnn,select
{
  font-family: "Kaushan Script", cursive !important;
  margin-left: 50px;
  border-radius:5px;
  margin-top: 29px;
  padding:10px 30px;
  color:black;
  text-decoration: none;
  transition: 0.6s ease;
  transform: translate(-50%,-50%);
  font-family: verdana;
  font-weight: bold;
  border:4px solid #66FFCC;
  background-color: silver;
  font-size: 15px;
}
.active, .btnn:hover
{
  color:black;
  border:4px solid #66FFCC;
  background-color: white;
  text-shadow: 0 0 20px white;
}
</style>
<body>
<center>
  <div class="dropdown">
    <button onclick="myFunction()" class="dropbtn active">ADD</button>
      <div id="myDropdown" class="dropdown-content">
        <a href="admin_register.php?msg=">ADD FOOD ITEMS</a>
        <a href="admin_add_category.php?msg=">ADD CATEGORY</a>
        <a href="admin_add_table.php?msg=">ADD TABLES</a>
      </div>
    </div>
    <div class="dropdown">
    <button onclick="myFunction1()" class="dropbtn">VIEW</button>
      <div id="myDropdown1" class="dropdown-content">
        <a href="admin_view.php?msg=&category_no=1">VIEW FOOD ITEMS</a>
        <a href="admin_view_category.php?msg=">VIEW CATEGORY</a>
        <a href="admin_view_table.php?msg=">VIEW TABLES</a>
      </div>
    </div>
    <a href="frame.php"><input class="btnn" type="submit" value="TABLE"></a>
    <a href="feedback.php"><input class="btnn" type="submit" value="FEEDBACK"></a>
    <a href="status.php"><input class="btnn" type="submit" value="STATUS"></a>

    <a href="add_admin.php?msg=" style="position: absolute; right: 6%;"><img class="bt" src="image/add_user.png" width="50px" height="50px;"></a>
  <a href="admin_action.php?mode=logout" style="position: absolute; right: 1%;"><img class="btt" src="image/logout.jpg" width="40px" height="50px;"></a>
  </center>
	<div id="bo1">
		<center>
		<img src="image/add_table.png" width="40%" height="120%">
		</center>
	</div>
<form action="admin_action.php" method=post>
<center>
<div id="bo">
<table>
	<tr><td><br><br><label>ENTER ROOM NUMBER:&nbsp;&nbsp;</label>
	<td><br><br><input type="number" name="room_no" min=1 max=10></td></tr>
	<tr><td><br><label>ENTER TABLE NUMBER:&nbsp;&nbsp;</label>
	<td><br><input type="number" name="table_no" min=1 max=9></td></tr>
	<tr><td><br><label>ENTER TABLE CODE:&nbsp;&nbsp;</label>
	<td><br><input type="textbox" name="code"></td></tr>
	<tr><td><span style="color: grey">(Combination of characters)</span></tr>
</table>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<center>
	<input name="reset" type="reset" value="RESET">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input name="add" type="submit" value="SUBMIT">
</center>
<br>
<?php
if($_GET['msg']!="")
{
	echo "<font color=green><b>********* TABLE ADDED SUCCESSFULLY *********</b></font>";
}
?>
<br>
</div>
</center>
</form>
</body>
</html>
<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}
function myFunction1() {
  document.getElementById("myDropdown1").classList.toggle("show");
}
// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>