<?php
include_once("db_config.php"); 
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta http-equiv="refresh" content="60">
	<style type="text/css">
		.line
		{
			border-left: 6px solid green;
  			height: 200px;
		}
		table,th,td
		{
			border: 2px solid black;
        	border-collapse: collapse;
		}
		th
		{
			background-color: grey;
			color: white;
		}
		td
		{
			background-color: #e5e5e5;
			color: black ;
		}
		a
		{
			text-decoration: none;
			color: green;
			font-weight: bold;
		}
	</style>
</head>
<body>
<form method=post>
<?php
$sql="SELECT DISTINCT a.token_no, a.table_no, a.name, b.status from customer_details a, bill b where a.token_no=b.token_no and a.date='".date("y/m/d")."' and b.date='".date("y/m/d")."' and b.status='cancel' ";
$result=mysqli_query($con,$sql);
?>
<center><span style="color: black; font-weight: bolder; background-color: #66FFCC;">ORDERS CANCELED</span></center>
<table align="center">
<tr>
<th>TOKEN NO</th>
<th>TABLE NO</th>
<th>CUSTOMER NAME</th>
<th>ACTION</th>
</tr>
<tr>
<?php

while($row=mysqli_fetch_array($result))
{
?>
</tr>
<td><?php echo $row['token_no']; ?></td>
<td>Table &nbsp;<?php echo $row['table_no']; ?></td>
<td><?php echo $row['name']; ?></td>
<td><center><a href="admin_action.php?table_no=<?php echo $row['table_no'];?>&token_no=<?php echo $row['token_no'];?>&mode=cancel">&check;</a></center></td>
</tr>
<?php
}
?>
</table>
</form>
</body>
</html>

