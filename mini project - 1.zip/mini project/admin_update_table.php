<?php
include("db_config.php");
$table_no=$_GET['table_no'];
$sql="SELECT * FROM `login` where table_no='".$table_no."'";
$result=mysqli_query($con,$sql);
?>
<!DOCTYPE html>
<html>
<head>
<link rel="icon" href="image/logo.png">
<title>UPDATE TABLE</title>
<style>
.btnn
{
  font-family: "Kaushan Script", cursive !important;
  margin-left: 100px;
  border-radius:5px;
  margin-top: 29px;
  padding:10px 30px;
  color:black;
  text-decoration: none;
  transition: 0.6s ease;
  transform: translate(-50%,-50%);
  font-family: verdana;
  font-weight: bold;
  border:4px solid #66FFCC;
  background-color: silver;
  font-size: 15px;
}
.active, .btnn:hover
{
  color:black;
  border:4px solid #66FFCC;
  background-color: white;
  text-shadow: 0 0 20px white;
}
body
{
  background: url(image/backk.jpg);
  background-size: cover;
}
#bo 
{
  width: 50%;
  height: 79%;
  padding: 10px;
  border: 2px solid #e5e5e5;
  border-radius:10px;
  margin-top: 8%;
  background-color: #ffffff;
  border: 5px solid black;
  opacity: 0.9;
}
#bo1
{
  width: 50%;
  height: 7%;
  padding: 10px;
  border: 2px solid #e5e5e5;
  background-color: #ffffff;
  border: 5px solid black;
  opacity: 0.9;
  position: absolute;
  top: 115px;
  left: 24%;
}
input,option,select,textarea
{
  font-color:#e5e5e5; 
  box-sizing: border-box;
  border-radius:5px;
  border:2px solid #e5e5e5;
  padding:10px;
  font-size:15px;
}
table
{
  margin-left:15px;
  font-weight: bold;
    color: black;
    opacity: 1;
}

</style>
</head>
<body>
<span>
	<a href="admin_view_table.php?msg="><input class="btnn" type="submit" value="GO BACK"></a>
</span>
<?php
$row=mysqli_fetch_array($result);
?>
<form action="admin_action.php" method=post enctype="multipart/form-data">
<center>
<div id="bo1">
	<center>
		<img src="image/update_table.png" width="50%" height="130%">
		</center>
</div>
<div id="bo">
<table>
<tr><td><br><label>Code: &nbsp;&nbsp;</label>
<td><br><input type="text" name="code" value="<?php echo $row['code']; ?>"></td></tr>

<input type="hidden" value="<?php echo $_GET['table_no']; ?>" name="table_no"> 
</table>
<br><br>
<center>
	<input name="update_table" type="submit" value="UPDATE">
</center>
<br><br>
</div>
</center>
</form>
</body>
</html>