<?php
include_once('db_config.php');

//As said table number is carried out throught the session we can also check integrity
if ( ! isset($_GET['table_no']) ) 
{
  die("Please Login correctly");
}
//table_no and token_no is stored in variable using GET
//It is not secure to use GET variable it should be changed later
$table_no=$_GET['table_no'];
$token_no=$_GET['token_no'];

if(isset($_GET['table_no']))
{
  $sql="SELECT * FROM `login` where table_no='".$table_no."' ";
  $result=mysqli_query($con,$sql);
  $row=mysqli_fetch_array($result);
  //If the particular table is checked out and the admin when removes the table from ongoing table list it will go to the index page
  if($row['status']=='empty')
  {
    header("Location: index.php");
  }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>STATUS</title>
<link rel="icon" href="image/logo.png">
<!--Page is refreshed for every 30 seconds-->
<meta http-equiv="refresh" content="30">
<script type="text/javascript" src="script.js"></script>
<link rel="stylesheet" type="text/css" href="swiper_style.css">
<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
header
{
  background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url(image/back_image.jpg);
}
.btnn
{
  font-family: "Kaushan Script", cursive !important;
  margin-left: 100px;
  padding:10px 30px;
  color:black;
  text-decoration: none;
  transition: 0.6s ease;
  transform: translate(-50%,-50%);
  font-family: verdana;
  font-weight: bold;
  animation: glow 2s linear infinite;
  border:4px solid white;
  background-color: #4CAF50;
}
.active, .btnn:hover
{
  color:black;
  border:4px solid #4CAF50;
  background-color: white;
  text-shadow: 0 0 20px white;
}
@keyframes glow 
{
  0%
  {
    box-shadow: 0 0 0px #4CAF50;
  }
  50%
  {
    box-shadow: 0 0 20px #4CAF50;
  }
}

#middle 
{
  font-size:60px;
  text-shadow:  5px 5px 5px #4CAF50;
}
.title
{
  position: absolute;
  top: 40%;
  left: 46%;
  transform: translate(-45%,-50%); 
  color: blue;
}
#new
{
  position: absolute;
  top: 60%;
  text-transform: uppercase; 
  font-size:30px; 
  font-family: serif; 
  color:white;
  left: 18%;
}
</style>
</head>
<body onload="timer()">
<header>
  <form method=post>
    <div class="main">
      <!--Logo is displayed-->
      <div class="logo" style="position: absolute; top:20px; left:20px">
        <img src="image/foodie.png">
      </div>
      <!--Date and time is displayed-->
      <ul>
        <li><h2 class="time">Time  &nbsp;<span id="time_span"></span></h2></li><br>
        <li><h2 class="time">Date  &nbsp;<span id="date_span"></span></h2></li>
      </ul>
    </div>     
    <?php
    //From bill table the status is updated for every 30 seconds when the page reloads
    $sql="SELECT * FROM `bill` where table_no='".$table_no."' and token_no='".$token_no."' and `date`='". date("y/m/d") ."' ";
    $result=mysqli_query($con,$sql);
    $row=mysqli_fetch_array($result);
    //if status is to get the food from the food counter when admin is ready to deliver and when he updates that in status
    if($row['status']=='get it')
    {
    ?>
    <div id="new"><?php echo 'Please come and collect your order in food counter<br><br> Bring your table card' ?></div>
    <?php
    }

    //if the user cancels the order the following is displayed
    if($row['status']=='cancel')
    {
    ?>
    <div id="new"><?php echo 'Please..... Return the table card to the food counter' ?></div>
    <?php
    }

    //if the status is not updated by admin and ordered only
    if($row['status']=='ordered')
    {
    ?>
    <div id="new"><?php echo 'Wait for sometime.....' ?></div>
    <?php
    }

    ?>
    <!--Some extra Message displayed-->
    <div class="title">
        <h1 id="middle">
        <center> W
        A
        I
        T
        &nbsp;
        &
        &nbsp;
        G
        R
        A
        B</center>
        <center>
        <span>C</span>
        <span>R</span>
        <span>U</span>
        <span>N</span>
        <span>C</span>
        <span>H</span></center>    
        </h1>
    </div>
    <a href="index.php" target="_blank" style="position:absolute; right:10px; bottom:15%;" class="btnn">ORDER AGAIN</a>
    <?php
    if($row['status']=='delivered')
    {   
      header('Location: index.php');
    }
    if($row['status']!='get it')
    {
    ?>
      <input style="position:absolute; right:10px; bottom:5%;" class="btnn" type="submit" name="cancel" value="CANCEL ORDER">
    <?php
    }
    ?>
  </form>
</header>
</body>
</html>
<?php
//When the user wants to cancel the order placed
if(isset($_POST["cancel"]))
{
  $table_no=$_GET['table_no'];
  $token_no=$_GET['token_no'];
  //In bill table the status is updated as cancel
  $sql="UPDATE `bill` SET `status`='cancel' where `table_no`='".$table_no."' and `token_no`='".$token_no."' ";
  $result=mysqli_query($con,$sql);
  //The quantity of items is again set as one
  $sql="UPDATE `item` SET `quantity`=1";
  $result=mysqli_query($con,$sql);
  if($result)
  {
    header("Location: last.php?table_no=$table_no&token_no=$token_no&mode=cancel");
  }
  else
  {
    echo "ERROR: Order closed FAILED";
  }
}
?>