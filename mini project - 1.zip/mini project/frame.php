<?php
include_once('db_config.php');
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="icon" href="image/logo.png">
	<title>ADMIN</title>
	<style type="text/css">
		body
		{
			background-color: grey;
		}
		iframe
		{
			background-color: white;
			border: 3px solid black;
			opacity: 0.9;
		}
		.btnn,select
{
  font-family: "Kaushan Script", cursive !important;
  margin-left: 50px;
  border-radius:5px;
  margin-top: 29px;
  padding:10px 30px;
  color:black;
  text-decoration: none;
  transition: 0.6s ease;
  transform: translate(-50%,-50%);
  font-family: verdana;
  font-weight: bold;
  border:4px solid #66FFCC;
  background-color: silver;
  font-size: 15px;
}
.active, .btnn:hover
{
  color:black;
  border:4px solid #66FFCC;
  background-color: white;
  text-shadow: 0 0 20px white;
}
body
{
  background: url(image/backk.jpg);
  background-size: cover;
}

.dropbtn {
	font-family: "Kaushan Script", cursive !important;
  margin-left: 50px;
  border-radius:5px;
  margin-top: 29px;
  padding:10px 30px;
  color:black;
  text-decoration: none;
  transition: 0.6s ease;
  transform: translate(-50%,-50%);
  font-family: verdana;
  cursor: pointer;
  font-weight: bold;
  border:4px solid #66FFCC;
  background-color: silver;
  font-size: 15px;
}

.dropbtn:hover, .dropbtn:focus {
  background-color: white;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  overflow: auto;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  padding:10px 30px;
  color:black;
  text-decoration: none;
  display: block;
}

.dropdown a:hover {background-color: #ddd;}

.show {display: block;}
img
{
  border-radius: 10px;
  border: 5px solid #e5e5e5;
}
img:hover
{
  border: 5px solid white;
}
.bt
{
  border-radius: 50px;
  border: 5px solid lightblue;
}
.bt:hover
{
  border: 5px solid white;
}
</style>
</head>
<body>
<center>

    <div class="dropdown">
		<button onclick="myFunction()" class="dropbtn">ADD</button>
  		<div id="myDropdown" class="dropdown-content">
    		<a href="admin_register.php?msg=">ADD FOOD ITEMS</a>
    		<a href="admin_add_category.php?msg=">ADD CATEGORY</a>
    		<a href="admin_add_table.php?msg=">ADD TABLES</a>
  		</div>
    </div>
    
    <div class="dropdown">
    <button onclick="myFunction1()" class="dropbtn">VIEW</button>
      <div id="myDropdown1" class="dropdown-content">
        <a href="admin_view.php?msg=&category_no=1">VIEW FOOD ITEMS</a>
        <a href="admin_view_category.php?msg=">VIEW CATEGORY</a>
        <a href="admin_view_table.php?msg=">VIEW TABLES</a>
      </div>
    </div>
    <a href="frame.php"><input class="btnn active" type="submit" value="TABLE"></a>
    <a href="feedback.php"><input class="btnn" type="submit" value="FEEDBACK"></a>
    <a href="status.php"><input class="btnn" type="submit" value="STATUS"></a>

  <a href="add_admin.php?msg=" style="position: absolute; right: 6%;"><img class="bt" src="image/add_user.png" width="50px" height="50px;"></a>
  <a href="admin_action.php?mode=logout" style="position: absolute; right: 1%;"><img src="image/logout.jpg" width="40px" height="50px;"></a>

  </center>
	<iframe src="empty_status.php" width="220" height="340" style="position: absolute; left:10px; top: 70px;"></iframe>
	<iframe src="on_going.php" width="220" height="310" style="position: absolute; left:10px; top: 430px;"></iframe>
	<iframe src="deliver_details.php" width="510" height="340" style="position: absolute; left:250px; top: 70px;"></iframe>
	<iframe src="order_placed.php" width="290" height="670" style="position: absolute; left:780px; top: 70px;"></iframe>
	<iframe src="order_canceled.php" width="510" height="310" style="position: absolute; left:250px; bottom: 10px;"></iframe>
	<iframe src="admin_order.php" width="430" height="670" style="position: absolute; left: 1090px; top:70px;bottom: 10px;"></iframe>
</body>
</html>
<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}
function myFunction1() {
  document.getElementById("myDropdown1").classList.toggle("show");
}
function myFunction2() {
  document.getElementById("myDropdown2").classList.toggle("show");
}
// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

</script>