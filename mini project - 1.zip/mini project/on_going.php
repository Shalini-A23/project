<?php
include_once("db_config.php"); 
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta http-equiv="refresh" content="60">
	<style type="text/css">
		.line
		{
			border-left: 6px solid green;
  			height: 200px;
		}
		table,th,td
		{
			border: 2px solid black;
        	border-collapse: collapse;
		}
		th
		{
			background-color: grey;
			color: white;
		}
		td
		{
			background-color: #e5e5e5;
			color: black ;
		}
		a
		{
			text-decoration: none;
		}
	</style>
</head>
<body>
<form method=post>
<center><span style="color: black; font-weight: bolder; background-color: #66FFCC;">ONGOING TABLE</span></center>
<?php
$sql="SELECT * FROM `login` WHERE `status`='active' && mode='user' ";
$result=mysqli_query($con,$sql);
?>
<table align="center">
<tr>
<th>&nbsp;TABLE NO&nbsp;</th>
<th>&nbsp;ACTION&nbsp;</th>
</tr>
<tr>
<?php
while($row=mysqli_fetch_array($result))
{
?>
</tr>
<td>Table &nbsp;<?php echo $row['table_no']; ?></td>
<td><center><a href="admin_action.php?table_no=<?php echo $row['table_no'];?>&mode=checked_out" style="color: red; font-weight: bolder;">&times; &nbsp;</a></center></td>
</tr>
<?php
}
?>
</table>
</form>
</body>
</html>

