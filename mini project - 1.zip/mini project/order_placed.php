<?php
include_once("db_config.php"); 
$sql="SELECT * FROM `bill` ";
$result=mysqli_query($con,$sql);
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php
	while($row=mysqli_fetch_array($result))
	{
		if($row['status']=='ordered')
		{
	?>
	<meta http-equiv="refresh" content="60">
	<?php
		}
	}
	?>
	<style type="text/css">
		table,th,td
		{
			border: 2px solid black;
        	border-collapse: collapse;
		}
		th
		{
			background-color: grey;
			color: white;
		}
		td
		{
			background-color: #e5e5e5;
			color: black ;
		}
		a
		{
			text-decoration: none;
		}
	</style>
</head>
<body>
<form method=post>
<center><span style="color: black; font-weight: bolder; background-color: #66FFCC;">ORDERS PLACED</span></center>
<?php
$sql="SELECT DISTINCT table_no,token_no FROM `bill` WHERE `status`='ordered' and `date`='". date("y/m/d") ."' ORDER BY token_no ASC ";
$result=mysqli_query($con,$sql);
?>
<table align="center">
<th>TOKEN NO</th>
<th>TABLE NO</th>
<tr>

<?php
while($row=mysqli_fetch_array($result))
{
?>

</tr>
<td><?php echo $row['token_no']; ?></td>
<td>Table &nbsp;<?php echo $row['table_no']; ?></td>
</tr>

<?php
}
?>

</form>
</body>
</html>
