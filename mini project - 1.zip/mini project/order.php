<?php
include_once('db_config.php');
//if the place order button is clicked in the table where the list of item is available 
if(isset($_POST['order']))
{ 
	session_start();
	$table_no=$_GET['table_no'];
	$token_no=$_GET['token_no'];
	$total_price=$_SESSION['total_price'];
	//In bill table the status is updated as ordered
	$sql="UPDATE `bill` SET `status`='ordered' where `table_no`='".$table_no."' and `token_no`='".$token_no."' ";
	$result=mysqli_query($con,$sql);
	//In customer_details table the total amount is updated where the customer name and other details are present
	$sql="UPDATE `customer_details` SET `total_amt`='".$total_price."' where `table_no`='".$table_no."' and `token_no`='".$token_no."' and `date`='". date("y/m/d") ."' ";
	$result=mysqli_query($con,$sql);
	if($result)
	{			
		//Redirects to last.php where the status of the order will be displayed whether to be waited or to get food in food counter
		header("Location: last.php?table_no=$table_no&token_no=$token_no");
	}
	else
	{
		echo "fail";
	}
}
//if the user want to remove a selected item 
if($_GET['mode']=="delete")
{ 
	$table_no=$_GET['table_no'];
	$bill_id=$_GET['bill_id'];
	$token_no=$_GET['token_no'];
	//The particular item is removed form the bill table and not included bill
	$sql="DELETE from `bill` where bill_id='".$bill_id."' and token_no='".$token_no."' ";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		//Again it goes to the table where the selected items are displayed
		header("Location: info.php?table_no=$table_no&token_no=$token_no");
	}
	else
	{
		echo "ERROR: DELETED FAILED";
	}
}
//if the user want to increase the quantity of a particular item
elseif($_GET['mode']=="add")
{
	$table_no=$_GET['table_no'];
	$bill_id=$_GET['bill_id'];
	$token_no=$_GET['token_no'];
	//for every click one is incremented
	$quanadd=$_GET['quantity']+1;
	$price=$_GET['cost'] * $quanadd;
	//In bill table the quantity is updated for each click 
	$sql="UPDATE `bill` SET `quantity`='".$quanadd."', `price`='".$price."' where bill_id='".$bill_id."' and token_no='".$token_no."' ";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		//Again it goes to the table where the selected items are displayed
		header("Location: info.php?table_no=$table_no&token_no=$token_no");
	}
	else
	{
		echo "ERROR: quan update add FAILED";
	}
}
//if the user want to decrease the quantity of a particular item
elseif($_GET['mode']=="sub")
{
	$table_no=$_GET['table_no'];
	$bill_id=$_GET['bill_id'];
	$token_no=$_GET['token_no'];
	//for every click one is decremented
	$quansub=$_GET['quantity']-1;
	$price=$_GET['cost'] * $quansub;
	//If the quantity is already one then the quantity will not be decremented
	if($_GET['quantity']=="1")
	{
		header("Location: info.php?table_no=$table_no&token_no=$token_no");
	}
	//If qunaity is greater than one the decremet takes place
	else
	{
		//In bill table the quantity is updated for each click 
		$sql="UPDATE `bill` SET `quantity`='".$quansub."', `price`='".$price."' where bill_id='".$bill_id."' and token_no='".$token_no."' ";
		$result=mysqli_query($con,$sql);
		if($result)
		{
			//Again it goes to the table where the selected items are displayed
			header("Location: info.php?table_no=$table_no&token_no=$token_no");
		}
		else
		{
			echo "ERROR: quan update add FAILED";
		}
	}
}

?>