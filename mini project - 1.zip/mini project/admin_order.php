<?php
include_once("db_config.php"); 
?>
<!DOCTYPE html>
<html>
<head>
	<title>ADMIN ORDER</title>
	<meta http-equiv="refresh" content="60">
	<style type="text/css">
		a
		{
			text-decoration: none;
		}
	</style>
</head>
<body>
<form method=post>
<center><span style="color: black; font-weight: bolder; background-color: #66FFCC;">ORDER PLACED - ITEMS</span></center>
<br>
Token no: <input type="textbox" name="tb_no">&nbsp;<input type="submit" name="show" value="GET ORDER"><br><br><br><br>

<?php
if(isset($_POST["show"]))
{
$sql="SELECT * FROM `bill` where `status`='ordered' and `token_no`='".$_POST['tb_no']."' and `date`='". date("y/m/d") ."' ";
$result=mysqli_query($con,$sql);
?>

<table border="1">
		<tr><b>Token no: </b><?php echo $_POST['tb_no'] ?><br><br></tr>
		<tr><th>S.No</th>
			<th>Item name</th>
			<th>Quantity</th>
			<th>Price</th>
		</tr>
<tr>

<?php
$quantity=0;
$total_price=0;
$i=1;
$rowcount=0;
while($row=mysqli_fetch_array($result))
{
	$rowcount=mysqli_num_rows($result);
	$quantity+=$row['quantity'];
?>

</tr>
<td><?php echo $i++; ?></td>	
<td>
<?php 
	$sql1="SELECT item_name FROM `item` WHERE item_id='".$row['item_id']."' ";
	$result1=mysqli_query($con,$sql1);
	$row1=mysqli_fetch_array($result1);
	echo ucwords($row1['item_name']);
?></td>
<td><center><?php echo $row['quantity']; ?></center></td>
<td><center><?php echo $row['price']; ?></center></td>
<?php
$total_price+=$row['price'];
$table_no=$row['table_no']; 
$token_no=$row['token_no'];
}
?>

</tr>
</table><br>

TOTAL PRICE: <b><?php echo $total_price; ?></b><br>
TOTAL QUANTITY: <b><?php echo $quantity; ?></b><br>
TOTAL ITEMS: <b><?php echo $rowcount ?></b>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="admin_action.php?table_no=<?php echo $table_no;?>&token_no=<?php echo $token_no ;?>&mode=get_it"><span style="color: green; font-size: 20px; background-color: lightgrey; border: 1px solid black">&check;</span></a>

<?php
}
?>
<br>

</form>
</body>
</html>
<?php
if(isset($_POST["close"]))
{
	$table_no=$_POST['tb_no'];

	$sql="UPDATE `bill` SET `status`='finished' where `table_no`=".$table_no."";
	$result=mysqli_query($con,$sql);

	$sql="UPDATE `item` SET `quantity`=1";
	$result=mysqli_query($con,$sql);


	//$sql="UPDATE `table_details` SET `status`='order closed' where `table_no`=".$table_no." ";
	//$result=mysqli_query($con,$sql);

	if($result)
	{
		header("Location: admin_order.php");
	}else
	{
		echo "ERROR: Order closed FAILED";
	}
}
?>