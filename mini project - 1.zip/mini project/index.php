<?php
//Connection established
include_once('db_config.php');
$failure=false;
//Update session variable when new day starts
session_start();
if(!isset($_SESSION['date']))
{
	$_SESSION['date']=date('y/m/d');
}
if($_SESSION['date'] != date('y/m/d'))
{
	//destroy session when the day ends
	session_unset();
	session_destroy();
}
if(isset($_POST['login']))
{	
  	$table_no=$_POST['table_no'];
  	$code=$_POST['code'];
  	$name=$_POST['name'];
  	//To check whether the values given are empty or not
	if($table_no!=null && $code!=null)
	{
		//To check name in alpha characters
		$name_pattern = '/^[a-zA-Z ]+$/';
		if(!preg_match($name_pattern, $name))
		{
			$failure= "Please.... Enter your name in alphabets";
		}
		else
		{
  			//To Check login authentication
  			$sql="SELECT * FROM `login` where `table_no`='".$table_no."' AND `code`='".$code."' && mode='user' ";
  			$result=mysqli_query($con,$sql);
  			if(mysqli_num_rows($result)==1) 
  			{
  				//Updating token number
				if(!isset($_SESSION['token_no']))
				{
					$_SESSION['token_no']=1;
				}
				else
				{
					++$_SESSION['token_no'];
				}
				$token_no=$_SESSION['token_no'];
				//Update login status from empty to active 
  				$sql="UPDATE `login` SET `status`='active' where `table_no`='".$table_no."' ";
	 			$result=mysqli_query($con,$sql);
	 			//Insert into customer details the newly generated token no, name and other particulars
	 			$sql="INSERT INTO `customer_details`(`token_no`,`name`,`table_no`,`date`) VALUES('".$token_no."','".$name."','".$table_no."','".date("y/m/d")."')"; 
	 			$result=mysqli_query($con,$sql);
	 			if($result)
	 			{
	 				//table_no and token_no is carried throughtout the session
    	 			header("Location:item.php?table_no=$table_no&token_no=$token_no&category_no=1");
    			}
  			}
  			else
  			{
    			$failure= "Please....Check the table no and code and enter correct";
  			}
  		}
  	}
  	else
  	{
  		$failure="Please.... Enter the table no,code and your name and then try to login";
  	}
}
else
{
	$failure= "Please....Enter the table no, code and your name";
}
?>
<!DOCTYPE html>
<html lang=en>
<head>
	<link rel="icon" href="image/logo.png">
	<meta charset="UTF-8">
	<title>FOODIE</title>
	<script src="script.js"></script>
	<link rel="stylesheet" href="style.css">
	<style type="text/css">
		.button
		{
			position: absolute;
			top: 55%;
			left:50%;
			transform: translate(-50%,-50%);
		}
	</style>
</head>
<body onload="timer()">
<form method=post>
	<header>
		<!--To display date and time-->
		<div class="main">
			<ul>
				<li><h2 class="time">Time  &nbsp;<span id="time_span"></span></h2></li><br>
				<li><h2 class="time">Date  &nbsp;<span id="date_span"></span></h2></li>
			</ul>
		</div>
		<!--Geting inputs-->
		<div class="mid">
			<label style="font-size: 1.5em ;font-weight: bolder">Enter table number:&nbsp;</label>
			<input type="text" name="table_no" style="height: 20px; width: 20%; font-weight: bold; font-size: 14px;">
			<br>
			<label style="font-size: 1.5em ;font-weight: bolder">Enter code:&nbsp;</label> 
			<input type="text" name="code" style="height: 20px; width: 20%; font-weight: bold; font-size: 14px;"> &nbsp;
			<?php
			//if authentication failed message is displayed
			if ( $failure !== false ) 
			{
    			echo('<span style="color: red;">'.htmlentities($failure)."</span>\n");
			}
			?>
			<br><br>
			<label style="font-size: 1.5em ;font-weight: bolder">Enter Your Name:&nbsp;</label> 
			<input type="text" name="name" style="height: 20px; width: 40%; font-weight: bold; font-size: 14px;">
		</div>
		<!--Some extra Message displayed-->
		<div class="title">
			<h1>
				<span>C</span>
				<span>R</span>
				<span>U</span>
				<span>N</span>
				<span>C</span>
				<span>H</span>
				&nbsp;
				<span>T</span>
				<span>I</span>
				<span>M</span>
				<span>E</span>
			</h1>
		</div>
		<div class="button"><br><br><br><br><br><br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input class="btn" type="submit" name="login" value="SELECT FOOD ITEMS" id="clickme">
			<!--logo display at bottom right corner-->
			<img src="image/foodie.png" height="80px" width="200px" style="border: 5px solid black; position: absolute; top: 170%; left: 175%">
		</div>
	</header>
</form>
</body>
</html>