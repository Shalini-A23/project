function timer()
{
	var currentTime = new Date();
	var hours = currentTime.getHours();
	var minutes = currentTime.getMinutes();
	var sec = currentTime.getSeconds();
	if (minutes < 10)
	{
  		minutes = "0" + minutes;
	}
	if (sec < 10)
	{
    	sec = "0" + sec;
	}
	var ampm=(hours < 12) ? "AM" : "PM";
	hours=(hours > 12) ? hours - 12 : hours;
	var t_str = hours + ":" + minutes + ":" + sec + " "+ampm;
 	document.getElementById('time_span').innerHTML = t_str;
 	setTimeout(timer,1000);

	var currentDate=new Date();
	var date=currentDate.getDate();
	var month=currentDate.getMonth()+1;
	var year=currentDate.getYear()+1900;
	var d_str=date+"-"+month+"-"+year;
	document.getElementById('date_span').innerHTML=d_str;
}