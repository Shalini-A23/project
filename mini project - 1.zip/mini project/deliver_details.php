<?php
include_once("db_config.php"); 
?>
<!DOCTYPE html>
<html>
<head>
	<title>DELIVERY DETAILS</title>
	<meta http-equiv="refresh" content="60">
	<style type="text/css">
		.line
		{
			border-left: 6px solid green;
  			height: 200px;
		}
		table,th,td
		{
			border: 2px solid black;
        	border-collapse: collapse;
		}
		th
		{
			background-color: grey;
			color: white;
		}
		td
		{
			background-color: #e5e5e5;
			color: black ;
		}
		a
		{
			text-decoration: none;
		}
	</style>
</head>
<body>
<form method=post>
	<center><span style="color: black; font-weight: bolder; background-color: #66FFCC;">&nbsp;DELIVERY STATUS&nbsp;</span></center>
<?php
$sql="SELECT DISTINCT a.token_no, a.table_no, a.name, a.total_amt, a.payment_status, b.status from customer_details a, bill b where a.token_no=b.token_no and a.date='". date("y/m/d") ."' and b.date='". date("y/m/d") ."' and b.status='get it'";
$result=mysqli_query($con,$sql);
?>
<table align="center">
<th>&nbsp;TOKEN NO&nbsp;</th>
<th>&nbsp;TABLE NO&nbsp;</th>
<th>&nbsp;CUSTOMER NAME&nbsp;</th>
<th>&nbsp;AMOUNT&nbsp;</th>
<tr>
<?php

while($row=mysqli_fetch_array($result))
{
?>
</tr>
<td><?php echo $row['token_no']; ?></td>
<td>Table &nbsp;<?php echo $row['table_no']; ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['total_amt']; ?>
&nbsp;|&nbsp;<a href="admin_action.php?mode=delivered&token_no=<?php echo $row['token_no']?>&table_no=<?php echo $row['table_no']?>" style="color: green; font-weight: bolder;">&check;</a>
</td>
</tr>
<?php
}
?>
</table>
</form>
</body>
</html>

