<?php
include_once('db_config.php');
$error="";
if(isset($_POST['submit']))
{ 
  $table_no=$_POST['table_no'];
  $code=$_POST['code'];
  $sql="SELECT * FROM `login` where `table_no`='".$table_no."' AND `code`='".$code."' && mode='admin' ";
  $result=mysqli_query($con,$sql);
  if(mysqli_num_rows($result)==1) 
  {
    header('Location: frame.php');
  }
  else
  {
    $error="*Please enter valid username and password";
  }
}

?>
<html>
<head><title>FOODIE</title>
<link rel="icon" href="image/logo.png">
<style>
#box 
{
  width: 420px;
  height: 560px;
  padding: 10px;
  border: 2px solid #e5e5e5;
  border-radius:10px;
  background-color: white;
  }
.heading
{
  font-size:25px;
  font-family:arial;
}
.alg
{
  margin-left:-270px;
  font-weight:bold;
}
.alg1
{
  margin-left:-290px;
  font-weight:bold;
}

#hh
{
  line-height:0.5;
}
legend
{
  margin-left:-270px;
}
input
{
  font-color:#e5e5e5; 
  box-sizing: border-box;
  border-radius:5px;
  border:1px solid #e5e5e5;
  padding:18px;
  font-size:15px;
}
.d
{
  font-color:#e5e5e5; 
}
body
{
	background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url(image/back_image.jpg);
	background-size: cover;
}
</style>
</head>
<body>
<form action="" method="post">
<center><br><br><br><br><br>
<div id="box">
<br><br>
<img src="image/foodie.png" height="90px" width="220px"></tr>
<div id="hh"><p class="heading">Sign in as <b><a href="login_voter.php" style="color: black; text-decoration: none">admin</a></b></p></tr>
to continue with our service</div></tr><br>
<span style="font-size:15px; color: red"><?php echo $error ?></span>
<br><br><input size="42" type="textbox" placeholder="Enter Username" name="table_no">
<br><br><input size="42" type="password" placeholder="Enter password" name="code">
<!--<br><br><a class="alg" style="text-decoration:none; color:#1e90ff;" href="forgot.php">Forgot password?</a>-->
<br><br><br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;
<a class="alg1" style="text-decoration:none; color:#1e90ff;" href="voter_registration.php">Create account</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" size="100px" value="LOGIN" name="submit" style="background-color:#1e90ff;">
</div></center>
</form>
</body>
</html>