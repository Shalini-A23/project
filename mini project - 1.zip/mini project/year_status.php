<!DOCTYPE html>
<html>
<head>
	<title></title>
<style type="text/css">
	table
	{
		font-family: "Kaushan Script", cursive !important;
		border-collapse: collapse;
		box-shadow: 0px 0px 10px grey;
		font-weight: bold;
    color: black;
    opacity: 0.9;
    background-color: white;
    width: 30%;
    margin-left: 0px;
	}
	td,th
	{
		border: 1px solid black;
		padding: 20px;
	}
  tr,td
  {
    padding: 10px;
  }
	tr:nth-child(even)
	{
		background-color: f2f2f2;
	}
	th
	{
		background-color: #4CAF50;
		color: white;
	}
	img
	{
		width: 210px;
		height: 150px;
	}
</style>
</head>
<body>
<center style="font-family: cooper; color: grey; text-shadow: 2px 2px black;"><h1><span style="background-color: lightblue">&nbsp;YEAR STATUS&nbsp;</span></h1></center>
<center>
<?php
include_once("db_config.php");
$sql="SELECT COUNT(*) from `customer_details` WHERE `date`='".date('Y-m-d')."' ";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);
?>
<table border="1" style="position: absolute; left: 50px; top: 90px">
<tr>
<th>NUMBER OF CUSTOMERS</th>
</tr>
<tr>
<td><center><?php echo $row[0] ?></center></td>
</tr>
</table>

<?php
$sql1="SELECT COUNT(*) from `customer_details` WHERE `date`='".date('Y-m-d')."' && payment_status='paid' ";
$result1=mysqli_query($con,$sql1);
$row1=mysqli_fetch_array($result1);
?>
<table border="1" style="position: absolute; left: 430px; top: 90px">
<tr>
<th>ORDERS PAID</th>
</tr>
<tr>
<td><center><?php echo $row1[0] ?></center></td>
</tr>
</table>

<?php
$sql2="SELECT COUNT(*) from `customer_details` WHERE `date`='".date('Y-m-d')."' && payment_status='canceled' ";
$result2=mysqli_query($con,$sql2);
$row2=mysqli_fetch_array($result2);
?>
<table border="1" style="position: absolute; left: 810px; top: 90px">
<tr>
<th>ORDER CANCELED</th>
</tr>
<tr>
<td><center><?php echo $row2[0] ?></center></td>
</tr>
</table>

<?php
$sql3="SELECT SUM(quantity) FROM `bill` WHERE `date`='".date('Y-m-d')."' && status='delivered' ";
$result3=mysqli_query($con,$sql3);
$row3=mysqli_fetch_array($result3);
?>
<table border="1" style="position: absolute; left: 250px; top: 260px">
<tr>
<th>NUMBER OF ITEMS SOLD</th>
</tr>
<tr>
<td><center><?php echo $row3[0] ?></center></td>
</tr>
</table>

<?php
$sql4="SELECT SUM(total_amt) FROM `customer_details` WHERE `date`='".date('Y-m-d')."' && payment_status!='canceled' ";
$result4=mysqli_query($con,$sql4);
$row4=mysqli_fetch_array($result4);
?>
<table border="1" style="position: absolute; left: 640px; top: 260px">
<tr>
<th>TOTAL AMOUNT</th>
</tr>
<tr>
<td><center><?php echo $row4[0] ?></center></td>
</tr>
</table>

<?php
$sql4="SELECT COUNT(*) from `feedback` WHERE `date`='".date('Y-m-d')."' ";
$result4=mysqli_query($con,$sql4);
$row4=mysqli_fetch_array($result4);
?>
<table border="1" style="position: absolute; left: 450px; top: 430px">
<tr>
<th>NUMBER OF ISSUES</th>
</tr>
<tr>
<td><center><?php echo $row4[0] ?></center></td>
</tr>
</table>

</center>
</body>
</html>