<?php
include("db_config.php");
$item_id=$_GET['item_id'];
$sql="SELECT * FROM `item` where item_id='".$item_id."'";
$result=mysqli_query($con,$sql);
?>
<!DOCTYPE html>
<html>
<head>
<link rel="icon" href="image/logo.png">
<title>UPDATE FOOD ITEMS</title>
<style>
.btnn
{
  font-family: "Kaushan Script", cursive !important;
  margin-left: 100px;
  border-radius:5px;
  margin-top: 29px;
  padding:10px 30px;
  color:black;
  text-decoration: none;
  transition: 0.6s ease;
  transform: translate(-50%,-50%);
  font-family: verdana;
  font-weight: bold;
  border:4px solid #66FFCC;
  background-color: silver;
  font-size: 15px;
}
.active, .btnn:hover
{
  color:black;
  border:4px solid #66FFCC;
  background-color: white;
  text-shadow: 0 0 20px white;
}
body
{
  background: url(image/backk.jpg);
  background-size: cover;
}
#bo 
{
  width: 50%;
  height: 79%;
  padding: 10px;
  border: 2px solid #e5e5e5;
  border-radius:10px;
  margin-top: 8%;
  background-color: #ffffff;
  border: 5px solid black;
  opacity: 0.9;
}
#bo1
{
  width: 50%;
  height: 7%;
  padding: 10px;
  border: 2px solid #e5e5e5;
  background-color: #ffffff;
  border: 5px solid black;
  opacity: 0.9;
  position: absolute;
  top: 115px;
  left: 24%;
}
input,option,select,textarea
{
  font-color:#e5e5e5; 
  box-sizing: border-box;
  border-radius:5px;
  border:2px solid #e5e5e5;
  padding:10px;
  font-size:15px;
}
table
{
  margin-left:15px;
  font-weight: bold;
    color: black;
    opacity: 1;
}

</style>
</head>
<body>
<span>
	<a href="admin_view.php?msg=&category_no=<?php echo $_GET['category_no'] ?>"><input class="btnn" type="submit" value="GO BACK"></a>
</span>
<?php
$row=mysqli_fetch_array($result);
?>
<form action="admin_action.php?category_no=<?php echo $_GET['category_no']?>" method=post enctype="multipart/form-data">
<center>
<div id="bo1">
	<center>
		<img src="image/add_update.png" width="50%" height="130%">
		</center>
</div>
<div id="bo">
<table>
<tr><td><br><label>Item Name: &nbsp;&nbsp;</label>
<td><br><input type="text" name="item_name" value="<?php echo $row['item_name']; ?>"></td></tr>

<tr><td><br><label>Cost: &nbsp;&nbsp;</label>
<td><br><input type="text" name="cost" value="<?php echo $row['cost']; ?>"></td></tr>

<tr><td><br><label>IMAGE: &nbsp;&nbsp;</label>
<td><br><img id="output" style="height: 150px; width: 150px; border:2px solid #e5e5e5;"></td>
<!--src="image/<?php echo $row['image']; ?>-->
<td><br><input type="file" name="image" id="file" onchange="loadFile(event)"></td></tr>
<input type="hidden" value="<?php echo $_GET['item_id']; ?>" name="item_id"> 
</table>
<br><br>
<center>
	<input name="update" type="submit" value="UPDATE">
</center>
<br><br>
</div>
</center>
</form>
<script>
var loadFile = function(event) {
	var image = document.getElementById('output');
	image.src = URL.createObjectURL(event.target.files[0]);
};
</script>
</body>
</html>