<?php
include_once("db_config.php"); 
//As said table number is carried out throught the session we can also check integrity
if ( ! isset($_GET['table_no']) ) 
{
  die("Please Login correctly");
}
session_start();
 //table_no and token_no is stored in variable using GET
//It is not secure to use GET variable it should be changed later
$token_no=$_GET['token_no'];
$table_no=$_GET['table_no'];
?>
<!DOCTYPE html>
<html>
<head>
<link rel="icon" href="image/logo.png">
<title>ORDERS</title>
<link rel="stylesheet" type="text/css" href="swiper_style.css">
<style type="text/css">
.btnn
{
  font-family: "Kaushan Script", cursive !important;
  margin-left: 100px;
  border:4px solid #4CAF50;
  padding:10px 30px;
  color:black;
  background-color: white;
  text-decoration: none;
  transition: 0.6s ease;
  transform: translate(-50%,-50%);
  font-family: verdana;
  font-weight: bold;
  animation: glow 2s linear infinite;
  border-radius: 25px;
}
.active, .btnn:hover
{
  color:black;
  background-color: #EAEDED;
  text-shadow: 0 0 20px white;
  border-radius: 0px;
}
@keyframes glow 
{
  0%
  {
    box-shadow: 0 0 0px #4CAF50;
  }
  50%
  {
    box-shadow: 0 0 20px #4CAF50;
  }
}
table
{
	font-family: "Kaushan Script", cursive !important;
	border-collapse: collapse;
	box-shadow: 0px 0px 10px grey;
}
td,th
{
	border: 1px solid black;
	padding: 20px;
}
tr:nth-child(even)
{
	background-color: f2f2f2;
}
th
{
  background-color: #4CAF50;
	color: white;
}
td
{
	background-color: white;
}
.button
{
  margin-left: -80px;
}
</style>
</head>
<body>
<form action="order.php?table_no=<?php echo $table_no;?>&token_no=<?php echo $token_no;?>" method="post">
  <div class="button">
    <center>
    <!--The category is fetched from the category table so that it will be easy if admin wants to change or add-->
    <?php
    $sql="SELECT DISTINCT * from category where status='1' ";
    $result=mysqli_query($con,$sql);
    while($row=mysqli_fetch_array($result))
    {
    ?>
      <a style="text-transform: uppercase;" class="btn active" href="item.php?category_no=<?php echo $row['category_no'] ?>&table_no=<?php echo $table_no;?>&token_no=<?php echo $token_no;?>"><?php echo $row['name']; ?></a>
    <?php
    }
    ?>
    </center>
  </div>
  <table align="center" style="margin-top: 60px">
  <tr>
  <th>S.No</th>
  <th>CATEGORY</th>
  <th>ITEM NAME</th>
  <th>COST</th>
  <th>QUANTITY</th>
  <th>PRICE</th>
  <th>REMOVE</th>
  </tr>
  <tr>
  <!--From the bill table the selected item in displayed in the table-->
  <?php
  $sql="SELECT * FROM `bill` where table_no='".$table_no."' and  `status`='selected' and token_no='".$token_no."' and `date`='". date("y/m/d") ."' ";
  $result=mysqli_query($con,$sql);
  $total_price=0;
  $i=1;
  while($row=mysqli_fetch_array($result))
  {
    $sql1="SELECT item_name,category_no,cost FROM `item` WHERE item_id='".$row['item_id']."' ";
    $result1=mysqli_query($con,$sql1);
    $row1=mysqli_fetch_array($result1);

    $sql2="SELECT name FROM `category` WHERE category_no='".$row1['category_no']."' ";
    $result2=mysqli_query($con,$sql2);
    $row2=mysqli_fetch_array($result2);

  ?>
  </tr>
  <td><?php echo $i++; ?></td>		
  <td><?php echo ucfirst($row2['name']); ?></td>
  <td style="text-transform: uppercase"><?php echo $row1['item_name']; ?></td>
  <td><?php echo $row1['cost']; ?></td>
  <td><a style="text-decoration: none;color: red; font-weight: bold; background-color: #e5e5e5" href="order.php?mode=add&bill_id=<?php echo $row['bill_id'] ?>&quantity=<?php echo $row['quantity'] ?>&cost=<?php echo $row1['cost'] ?>&table_no=<?php echo $table_no;?>&token_no=<?php echo $token_no;?>">&#43;</a>&nbsp;&nbsp;&nbsp;<?php echo $row['quantity']; ?>&nbsp;&nbsp;&nbsp;<a style="text-decoration: none;color: red; font-weight: bold; background-color: #e5e5e5" href="order.php?mode=sub&bill_id=<?php echo $row['bill_id'] ?>&quantity=<?php echo $row['quantity'] ?>&cost=<?php echo $row1['cost'] ?>&table_no=<?php echo $table_no;?>&token_no=<?php echo $token_no;?>">&#8722;</a></td>
  <td style="text-align: right;"><?php echo $row['price']; ?></td>
  <td><center><a style="text-decoration: none;color: red; font-weight: bold; " href="order.php?mode=delete&bill_id=<?php echo $row['bill_id'] ?>&table_no=<?php echo $table_no;?>&token_no=<?php echo $token_no;?>">&times;</a></center></td>
  <?php
  $total_price+=$row['price']; 
  }
  ?>
  </tr>
  </table><br>
  <table style="position: absolute; left: 330px;">
  <th>TOTAL PRICE</th>
  <tr><td><?php echo $total_price; 
  $_SESSION['total_price']=$total_price;
  ?></td></tr>
  </table><br><br>
  <center>
  <input style="margin-left: 870px" class="btnn" type="submit" name="order" value="PLACE ORDER">
  </center>
</form>
</body>
</html>
