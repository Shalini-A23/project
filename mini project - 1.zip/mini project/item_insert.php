 <?php
include_once("db_config.php");
$quantity=$_GET['quantity'];
$item_id=$_GET['item_id'];
$table_no=$_GET['table_no'];
$token_no=$_GET['token_no'];	

$sql="SELECT cost FROM `item` WHERE item_id='".$_GET['item_id']."' ";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);
$cost=$row['cost'];
$price=$quantity * $cost;

$sql="INSERT INTO `bill`(`table_no`,`token_no`,`item_id`,`quantity`,`price`,`status`,`date`) VALUES ('".$table_no."','".$token_no."','".$item_id."','".$quantity."', '".$price."','selected','". date("y/m/d") ."')";
$result=mysqli_query($con,$sql);
if($result)
{
	header("location: info.php?table_no=$table_no&token_no=$token_no");
}
else
{
	echo "ERROR";
}
?>