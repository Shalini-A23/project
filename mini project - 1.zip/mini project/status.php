<!DOCTYPE html>
<html>
<head>
  <link rel="icon" href="image/logo.png">
  <title>STATUS</title>
  <style type="text/css">
  table
  {
    font-family: "Kaushan Script", cursive !important;
    border-collapse: collapse;
    box-shadow: 0px 0px 10px grey;
    font-weight: bold;
    color: black;
    opacity: 0.9;
    background-color: white;
    width: 80%;
    margin-left: 200px;
  }
  td,th
  {
    border: 1px solid black;
    padding: 20px;
  }
  th
  {
    background-color: #4CAF50;
    color: white;
  }

.btnn
{
  font-family: "Kaushan Script", cursive !important;
  margin-left: 50px;
  margin-top: 29px;
  padding:10px 30px;
  color:black;
  text-decoration: none;
  transition: 0.6s ease;
  transform: translate(-50%,-50%);
  font-family: verdana;
  font-weight: bold;
  border:4px solid #66FFCC;
  background-color: silver;
  font-size: 15px;
}

.active, .btnn:hover
{
  color:black;
  border:4px solid #66FFCC;
  background-color: white;
  text-shadow: 0 0 20px white;
}
input,option,select,textarea
{
  font-color:#e5e5e5; 
  box-sizing: border-box;
  border-radius:5px;
  border:2px solid #e5e5e5;
  padding:10px;
  font-size:15px;
}
.btnn a
{
  font-color:#e5e5e5; 
  box-sizing: border-box;
  border-radius:5px;
  border:2px solid #e5e5e5;
  padding:10px;
  font-size:15px;
}
body
{
  background: url(image/backk.jpg);
  background-size: cover;
}
iframe
    {
      background-color: white;
      border: 3px solid black;
      opacity: 0.9;
    }
.dropbtn {
  font-family: "Kaushan Script", cursive !important;
  margin-left: 50px;
  border-radius:5px;
  margin-top: 29px;
  padding:10px 30px;
  color:black;
  text-decoration: none;
  transition: 0.6s ease;
  transform: translate(-50%,-50%);
  font-family: verdana;
  cursor: pointer;
  font-weight: bold;
  border:4px solid #66FFCC;
  background-color: silver;
  font-size: 15px;
}

.active, .dropbtn:hover{
  color:black;
  border:4px solid #66FFCC;
  background-color: white;
  text-shadow: 0 0 20px white;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  overflow: auto;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  padding:10px 30px;
  color:black;
  text-decoration: none;
  display: block;
}

.dropdown a:hover {background-color: #ddd;}

.show {display: block;}
a
{
  text-decoration: none;
}
img
{
  border-radius: 10px;
  border: 5px solid #e5e5e5;
}
img:hover
{
  border: 5px solid white;
}
.bt
{
  border-radius: 50px;
  border: 5px solid lightblue;
}
.bt:hover
{
  border: 5px solid white;
}
</style>
</head>
<body>
<center>
  <div class="dropdown">
    <button onclick="myFunction()" class="dropbtn">ADD</button>
      <div id="myDropdown" class="dropdown-content">
        <a href="admin_register.php?msg=">ADD FOOD ITEMS</a>
        <a href="admin_add_category.php?msg=">ADD CATEGORY</a>
        <a href="admin_add_table.php?msg=">ADD TABLES</a>
      </div>
    </div>
    <div class="dropdown">
    <button onclick="myFunction1()" class="dropbtn">VIEW</button>
      <div id="myDropdown1" class="dropdown-content">
        <a href="admin_view.php?msg=&category_no=1">VIEW FOOD ITEMS</a>
        <a href="admin_view_category.php?msg=">VIEW CATEGORY</a>
        <a href="admin_view_table.php?msg=">VIEW TABLES</a>
      </div>
    </div>
    <a href="frame.php"><input class="btnn" type="submit" value="TABLE"></a>
    <a href="feedback.php"><input class="btnn" type="submit" value="FEEDBACK"></a>
    <a href="status.php"><input class="btnn active" type="submit" value="STATUS"></a>
      <a href="add_admin.php?msg=" style="position: absolute; right: 6%;"><img class="bt" src="image/add_user.png" width="50px" height="50px;"></a>
      <a href="admin_action.php?mode=logout" style="position: absolute; right: 1%;"><img src="image/logout.jpg" width="40px" height="50px;"></a>
  </center>
  <form action="" method=post enctype="multipart/form-data">
    <!--The category is fetched from the category table so that it will be easy if admin wants to change or add-->
    <center style="font-weight: bold; position: absolute; left: -20px; top:20%">
      <a style="text-transform: uppercase;" class="btnn" href="day_status.php" target="status">DAY STATUS</a><br><br><br><br>
      <a style="text-transform: uppercase;" class="btnn" href="week_status.php" target="status">WEEK STATUS</a><br><br><br><br>
      <a style="text-transform: uppercase;" class="btnn" href="month_status.php" target="status">MONTH STATUS</a><br><br><br><br>
      <a style="text-transform: uppercase;" class="btnn" href="year_status.php" target="status">YEAR STATUS</a><br><br><br><br>
  </center>
  </form>
  <br>
  <iframe src="day_status.php" width="1200px" height="600px" style="position: absolute; left: 270px; top: 110px;" name="status"></iframe>
</body>
</html>
<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

function myFunction1() {
  document.getElementById("myDropdown1").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>