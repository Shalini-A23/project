
<!DOCTYPE html>
<html>
<head>
  <link rel="icon" href="image/logo.png">
	<title>TABLES</title>
  <link rel="stylesheet" href="styles.css">
	<style type="text/css">
	table
	{
		font-family: "Kaushan Script", cursive !important;
		border-collapse: collapse;
		box-shadow: 0px 0px 10px grey;
		font-weight: bold;
    color: black;
    opacity: 0.9;
    background-color: white;
    width: 30%;
    margin-left: 0px;
	}
	td,th
	{
		border: 1px solid black;
		padding: 20px;
	}
  tr,td
  {
    padding: 10px;
  }
	tr:nth-child(even)
	{
		background-color: f2f2f2;
	}
	th
	{
		background-color: #4CAF50;
		color: white;
	}
  a
  {
    text-decoration: none;
  }
  .btt
{
  border-radius: 10px;
  border: 5px solid #e5e5e5;
}
.btt:hover
{
  border: 5px solid white;
}
.bt
{
  border-radius: 50px;
  border: 5px solid lightblue;
}
.bt:hover
{
  border: 5px solid white;
}
    .btnn,select
{
  font-family: "Kaushan Script", cursive !important;
  margin-left: 50px;
  border-radius:5px;
  margin-top: 29px;
  padding:10px 30px;
  color:black;
  text-decoration: none;
  transition: 0.6s ease;
  transform: translate(-50%,-50%);
  font-family: verdana;
  font-weight: bold;
  border:4px solid #66FFCC;
  background-color: silver;
  font-size: 15px;
}
.active, .btnn:hover
{
  color:black;
  border:4px solid #66FFCC;
  background-color: white;
  text-shadow: 0 0 20px white;
}
</style>
</head>
<body>
<center>
  <div class="dropdown">
    <button onclick="myFunction()" class="dropbtn">ADD</button>
      <div id="myDropdown" class="dropdown-content">
        <a href="admin_register.php?msg=">ADD FOOD ITEMS</a>
        <a href="admin_add_category.php?msg=">ADD CATEGORY</a>
        <a href="admin_add_table.php?msg=">ADD TABLES</a>
      </div>
    </div>
    <div class="dropdown">
    <button onclick="myFunction1()" class="dropbtn active">VIEW</button>
      <div id="myDropdown1" class="dropdown-content">
        <a href="admin_view.php?msg=&category_no=1">VIEW FOOD ITEMS</a>
        <a href="admin_view_category.php?msg=">VIEW CATEGORY</a>
        <a href="admin_view_table.php?msg=">VIEW TABLES</a>
      </div>
    </div>
    <a href="frame.php"><input class="btnn" type="submit" value="TABLE"></a>
    <a href="feedback.php"><input class="btnn" type="submit" value="FEEDBACK"></a>
    <a href="status.php"><input class="btnn" type="submit" value="STATUS"></a>

    <a href="add_admin.php?msg=" style="position: absolute; right: 6%;"><img class="bt" src="image/add_user.png" width="50px" height="50px;"></a>
  <a href="admin_action.php?mode=logout" style="position: absolute; right: 1%;"><img class="btt" src="image/logout.jpg" width="40px" height="50px;"></a>
  </center>
<?php
if($_GET['msg']!='')
{
	//echo "<font color=pink><b>********* ".$_GET['msg']." *********</b></font>";
	echo "<script>confirm('*********".$_GET['msg']."*********')</script>";
}
?>
<br><br><br>
<center>
<?php
include_once("db_config.php");
$sql="SELECT DISTINCT * from login WHERE mode='user' ";
$result=mysqli_query($con,$sql);
$i=1;
?>
<table border="1">
<tr>
<th>S.No</th>
<th>TABLE NUMBER</th>
<th>CODE</th>
<th>ACTION</th>
</tr>

<tr>
<?php
while($row=mysqli_fetch_array($result))
{
?>
</tr>
<?php
if($row['status']=='0')
{
?>
<tr style="background-color: #e5e5e5; color: grey">
<?php
}
else
{
?>

<tr style="background-color: white;">
<?php
}
?>
<td><center><?php echo $i++ ?></center></td>
<td style="text-transform: uppercase;"><?php echo $row['table_no']; ?></td>
<td><?php echo $row['code']; ?></td>
<td>
<center>
<?php
echo "<a onclick=\"return confirm('Are you sure to DELETE this table?')\" href=\"admin_action.php?mode=delete_table&table_no=".$row['table_no']."\"><font color=red>&times</font></a>";
?>
&nbsp;|&nbsp;
<a href="admin_update_table.php?table_no=<?php echo $row['table_no'] ;?>&mode=update_table" style="color: blue">&#10000;</a>|&nbsp;
<a href="admin_action.php?table_no=<?php echo $row['table_no'];?>&mode=do_table">
<?php
if($row['status']=='0')
{
?>
<span style="color: grey">
<?php
}
else
{
?>
<span style="color: orange">
<?php
}
?>
&starf;</span>
</a>
</center>
</td>
</tr>

<tr>
<?php
}
?>
</tr>
</table>
</center>
</body>
</html>
<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

function myFunction1() {
  document.getElementById("myDropdown1").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>